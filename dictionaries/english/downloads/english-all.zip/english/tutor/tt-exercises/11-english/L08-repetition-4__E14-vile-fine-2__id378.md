# vile fine 2

**Course:** English  
**Lesson 8:** Repetition 4  
**Exercise 14** (ID: 378)

## Text to type

```
vile fine vent vale back bans bags tins gift grit herb hand
```

## Metadata

| Field | Value |
|-------|-------|
| Error limit | 2 |
| Speed limit (cpm) | 0 |
| Star: speed | 0 |
| Star: errors | 0 |
| Lightning: speed | 230 |
| Lightning: errors | 255 |
| Type | 0 |

---
*Source: TT*
