# pastime

**Course:** English layout  
**Lesson 8:** Middle words 3  
**Exercise 2** (ID: 1883)

## Text to type

```
pastime pastime pastime pastime pastime pastime pastime pastime pastime pastime
```

## Metadata

| Field | Value |
|-------|-------|
| Error limit | 2 |
| Speed limit (cpm) | 0 |
| Star: speed | 0 |
| Star: errors | 0 |
| Lightning: speed | 200 |
| Lightning: errors | 255 |
| Type | 0 |

---
*Source: TT*
