# Dot 2

**Course:** English new  
**Lesson 12:** Dot and comma  
**Exercise 4** (ID: 3229)

## Text to type

```
. .. ... .... ... .. .
```

## Metadata

| Field | Value |
|-------|-------|
| Error limit | 2 |
| Speed limit (cpm) | 0 |
| Star: speed | 0 |
| Star: errors | 0 |
| Lightning: speed | 180 |
| Lightning: errors | 255 |
| Type | 0 |

---
*Source: TT*
